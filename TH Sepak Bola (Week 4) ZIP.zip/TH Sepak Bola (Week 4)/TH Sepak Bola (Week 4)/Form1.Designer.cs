﻿namespace TH_Sepak_Bola__Week_4_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_SoccerTeamList = new System.Windows.Forms.Label();
            this.lbl_ChooseCountry = new System.Windows.Forms.Label();
            this.lbl_ChooseTeam = new System.Windows.Forms.Label();
            this.comboBox_ChooseCountry = new System.Windows.Forms.ComboBox();
            this.comboBox_ChooseTeam = new System.Windows.Forms.ComboBox();
            this.lbl_AddingTeam = new System.Windows.Forms.Label();
            this.lbl_TeamName = new System.Windows.Forms.Label();
            this.lbl_TeamCountry = new System.Windows.Forms.Label();
            this.lbl_TeamCity = new System.Windows.Forms.Label();
            this.tBox_TeamName = new System.Windows.Forms.TextBox();
            this.tBox_TeamCountry = new System.Windows.Forms.TextBox();
            this.tBox_TeamCity = new System.Windows.Forms.TextBox();
            this.lbl_AddingPlayers = new System.Windows.Forms.Label();
            this.lbl_PlayerName = new System.Windows.Forms.Label();
            this.lbl_PlayerNumber = new System.Windows.Forms.Label();
            this.lbl_PlayerPosition = new System.Windows.Forms.Label();
            this.tBox_PlayerName = new System.Windows.Forms.TextBox();
            this.tBox_PlayerNumber = new System.Windows.Forms.TextBox();
            this.comboBox_PlayerPosition = new System.Windows.Forms.ComboBox();
            this.btn_AddTeam = new System.Windows.Forms.Button();
            this.btn_AddPlayers = new System.Windows.Forms.Button();
            this.listBox_Players = new System.Windows.Forms.ListBox();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_SoccerTeamList
            // 
            this.lbl_SoccerTeamList.AutoSize = true;
            this.lbl_SoccerTeamList.Location = new System.Drawing.Point(46, 72);
            this.lbl_SoccerTeamList.Name = "lbl_SoccerTeamList";
            this.lbl_SoccerTeamList.Size = new System.Drawing.Size(179, 25);
            this.lbl_SoccerTeamList.TabIndex = 0;
            this.lbl_SoccerTeamList.Text = "Soccer Team List";
            // 
            // lbl_ChooseCountry
            // 
            this.lbl_ChooseCountry.AutoSize = true;
            this.lbl_ChooseCountry.Location = new System.Drawing.Point(46, 124);
            this.lbl_ChooseCountry.Name = "lbl_ChooseCountry";
            this.lbl_ChooseCountry.Size = new System.Drawing.Size(173, 25);
            this.lbl_ChooseCountry.TabIndex = 1;
            this.lbl_ChooseCountry.Text = "Choose Country:";
            // 
            // lbl_ChooseTeam
            // 
            this.lbl_ChooseTeam.AutoSize = true;
            this.lbl_ChooseTeam.Location = new System.Drawing.Point(46, 181);
            this.lbl_ChooseTeam.Name = "lbl_ChooseTeam";
            this.lbl_ChooseTeam.Size = new System.Drawing.Size(158, 25);
            this.lbl_ChooseTeam.TabIndex = 2;
            this.lbl_ChooseTeam.Text = "Choose Team: ";
            // 
            // comboBox_ChooseCountry
            // 
            this.comboBox_ChooseCountry.FormattingEnabled = true;
            this.comboBox_ChooseCountry.Location = new System.Drawing.Point(225, 121);
            this.comboBox_ChooseCountry.Name = "comboBox_ChooseCountry";
            this.comboBox_ChooseCountry.Size = new System.Drawing.Size(213, 33);
            this.comboBox_ChooseCountry.TabIndex = 3;
            this.comboBox_ChooseCountry.SelectedIndexChanged += new System.EventHandler(this.comboBox_ChooseCountry_SelectedIndexChanged);
            // 
            // comboBox_ChooseTeam
            // 
            this.comboBox_ChooseTeam.FormattingEnabled = true;
            this.comboBox_ChooseTeam.Location = new System.Drawing.Point(225, 181);
            this.comboBox_ChooseTeam.Name = "comboBox_ChooseTeam";
            this.comboBox_ChooseTeam.Size = new System.Drawing.Size(213, 33);
            this.comboBox_ChooseTeam.TabIndex = 4;
            this.comboBox_ChooseTeam.SelectedIndexChanged += new System.EventHandler(this.comboBox_ChooseTeam_SelectedIndexChanged_1);
            // 
            // lbl_AddingTeam
            // 
            this.lbl_AddingTeam.AutoSize = true;
            this.lbl_AddingTeam.Location = new System.Drawing.Point(630, 57);
            this.lbl_AddingTeam.Name = "lbl_AddingTeam";
            this.lbl_AddingTeam.Size = new System.Drawing.Size(139, 25);
            this.lbl_AddingTeam.TabIndex = 5;
            this.lbl_AddingTeam.Text = "Adding Team";
            // 
            // lbl_TeamName
            // 
            this.lbl_TeamName.AutoSize = true;
            this.lbl_TeamName.Location = new System.Drawing.Point(476, 107);
            this.lbl_TeamName.Name = "lbl_TeamName";
            this.lbl_TeamName.Size = new System.Drawing.Size(134, 25);
            this.lbl_TeamName.TabIndex = 6;
            this.lbl_TeamName.Text = "Team Name:";
            // 
            // lbl_TeamCountry
            // 
            this.lbl_TeamCountry.AutoSize = true;
            this.lbl_TeamCountry.Location = new System.Drawing.Point(476, 154);
            this.lbl_TeamCountry.Name = "lbl_TeamCountry";
            this.lbl_TeamCountry.Size = new System.Drawing.Size(153, 25);
            this.lbl_TeamCountry.TabIndex = 7;
            this.lbl_TeamCountry.Text = "Team Country:";
            // 
            // lbl_TeamCity
            // 
            this.lbl_TeamCity.AutoSize = true;
            this.lbl_TeamCity.Location = new System.Drawing.Point(476, 207);
            this.lbl_TeamCity.Name = "lbl_TeamCity";
            this.lbl_TeamCity.Size = new System.Drawing.Size(115, 25);
            this.lbl_TeamCity.TabIndex = 8;
            this.lbl_TeamCity.Text = "Team City:";
            // 
            // tBox_TeamName
            // 
            this.tBox_TeamName.Location = new System.Drawing.Point(635, 104);
            this.tBox_TeamName.Name = "tBox_TeamName";
            this.tBox_TeamName.Size = new System.Drawing.Size(203, 31);
            this.tBox_TeamName.TabIndex = 9;
            // 
            // tBox_TeamCountry
            // 
            this.tBox_TeamCountry.Location = new System.Drawing.Point(635, 154);
            this.tBox_TeamCountry.Name = "tBox_TeamCountry";
            this.tBox_TeamCountry.Size = new System.Drawing.Size(203, 31);
            this.tBox_TeamCountry.TabIndex = 10;
            // 
            // tBox_TeamCity
            // 
            this.tBox_TeamCity.Location = new System.Drawing.Point(635, 204);
            this.tBox_TeamCity.Name = "tBox_TeamCity";
            this.tBox_TeamCity.Size = new System.Drawing.Size(203, 31);
            this.tBox_TeamCity.TabIndex = 11;
            // 
            // lbl_AddingPlayers
            // 
            this.lbl_AddingPlayers.AutoSize = true;
            this.lbl_AddingPlayers.Location = new System.Drawing.Point(1059, 57);
            this.lbl_AddingPlayers.Name = "lbl_AddingPlayers";
            this.lbl_AddingPlayers.Size = new System.Drawing.Size(157, 25);
            this.lbl_AddingPlayers.TabIndex = 12;
            this.lbl_AddingPlayers.Text = "Adding Players";
            // 
            // lbl_PlayerName
            // 
            this.lbl_PlayerName.AutoSize = true;
            this.lbl_PlayerName.Location = new System.Drawing.Point(900, 107);
            this.lbl_PlayerName.Name = "lbl_PlayerName";
            this.lbl_PlayerName.Size = new System.Drawing.Size(141, 25);
            this.lbl_PlayerName.TabIndex = 13;
            this.lbl_PlayerName.Text = "Player Name:";
            // 
            // lbl_PlayerNumber
            // 
            this.lbl_PlayerNumber.AutoSize = true;
            this.lbl_PlayerNumber.Location = new System.Drawing.Point(900, 154);
            this.lbl_PlayerNumber.Name = "lbl_PlayerNumber";
            this.lbl_PlayerNumber.Size = new System.Drawing.Size(160, 25);
            this.lbl_PlayerNumber.TabIndex = 14;
            this.lbl_PlayerNumber.Text = "Player Number:";
            // 
            // lbl_PlayerPosition
            // 
            this.lbl_PlayerPosition.AutoSize = true;
            this.lbl_PlayerPosition.Location = new System.Drawing.Point(900, 207);
            this.lbl_PlayerPosition.Name = "lbl_PlayerPosition";
            this.lbl_PlayerPosition.Size = new System.Drawing.Size(162, 25);
            this.lbl_PlayerPosition.TabIndex = 15;
            this.lbl_PlayerPosition.Text = "Player Position:";
            // 
            // tBox_PlayerName
            // 
            this.tBox_PlayerName.Location = new System.Drawing.Point(1064, 104);
            this.tBox_PlayerName.Name = "tBox_PlayerName";
            this.tBox_PlayerName.Size = new System.Drawing.Size(203, 31);
            this.tBox_PlayerName.TabIndex = 16;
            // 
            // tBox_PlayerNumber
            // 
            this.tBox_PlayerNumber.Location = new System.Drawing.Point(1064, 151);
            this.tBox_PlayerNumber.Name = "tBox_PlayerNumber";
            this.tBox_PlayerNumber.Size = new System.Drawing.Size(203, 31);
            this.tBox_PlayerNumber.TabIndex = 17;
            // 
            // comboBox_PlayerPosition
            // 
            this.comboBox_PlayerPosition.FormattingEnabled = true;
            this.comboBox_PlayerPosition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.comboBox_PlayerPosition.Location = new System.Drawing.Point(1064, 204);
            this.comboBox_PlayerPosition.Name = "comboBox_PlayerPosition";
            this.comboBox_PlayerPosition.Size = new System.Drawing.Size(203, 33);
            this.comboBox_PlayerPosition.TabIndex = 18;
            // 
            // btn_AddTeam
            // 
            this.btn_AddTeam.Location = new System.Drawing.Point(635, 261);
            this.btn_AddTeam.Name = "btn_AddTeam";
            this.btn_AddTeam.Size = new System.Drawing.Size(106, 44);
            this.btn_AddTeam.TabIndex = 19;
            this.btn_AddTeam.Text = "Add";
            this.btn_AddTeam.UseVisualStyleBackColor = true;
            this.btn_AddTeam.Click += new System.EventHandler(this.btn_AddTeam_Click);
            // 
            // btn_AddPlayers
            // 
            this.btn_AddPlayers.Location = new System.Drawing.Point(1064, 261);
            this.btn_AddPlayers.Name = "btn_AddPlayers";
            this.btn_AddPlayers.Size = new System.Drawing.Size(106, 44);
            this.btn_AddPlayers.TabIndex = 20;
            this.btn_AddPlayers.Text = "Add";
            this.btn_AddPlayers.UseVisualStyleBackColor = true;
            this.btn_AddPlayers.Click += new System.EventHandler(this.btn_AddPlayers_Click);
            // 
            // listBox_Players
            // 
            this.listBox_Players.FormattingEnabled = true;
            this.listBox_Players.ItemHeight = 25;
            this.listBox_Players.Location = new System.Drawing.Point(48, 261);
            this.listBox_Players.Name = "listBox_Players";
            this.listBox_Players.Size = new System.Drawing.Size(390, 229);
            this.listBox_Players.TabIndex = 21;
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(48, 512);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(124, 44);
            this.btn_Remove.TabIndex = 22;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1392, 623);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.listBox_Players);
            this.Controls.Add(this.btn_AddPlayers);
            this.Controls.Add(this.btn_AddTeam);
            this.Controls.Add(this.comboBox_PlayerPosition);
            this.Controls.Add(this.tBox_PlayerNumber);
            this.Controls.Add(this.tBox_PlayerName);
            this.Controls.Add(this.lbl_PlayerPosition);
            this.Controls.Add(this.lbl_PlayerNumber);
            this.Controls.Add(this.lbl_PlayerName);
            this.Controls.Add(this.lbl_AddingPlayers);
            this.Controls.Add(this.tBox_TeamCity);
            this.Controls.Add(this.tBox_TeamCountry);
            this.Controls.Add(this.tBox_TeamName);
            this.Controls.Add(this.lbl_TeamCity);
            this.Controls.Add(this.lbl_TeamCountry);
            this.Controls.Add(this.lbl_TeamName);
            this.Controls.Add(this.lbl_AddingTeam);
            this.Controls.Add(this.comboBox_ChooseTeam);
            this.Controls.Add(this.comboBox_ChooseCountry);
            this.Controls.Add(this.lbl_ChooseTeam);
            this.Controls.Add(this.lbl_ChooseCountry);
            this.Controls.Add(this.lbl_SoccerTeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_SoccerTeamList;
        private System.Windows.Forms.Label lbl_ChooseCountry;
        private System.Windows.Forms.Label lbl_ChooseTeam;
        private System.Windows.Forms.ComboBox comboBox_ChooseCountry;
        private System.Windows.Forms.ComboBox comboBox_ChooseTeam;
        private System.Windows.Forms.Label lbl_AddingTeam;
        private System.Windows.Forms.Label lbl_TeamName;
        private System.Windows.Forms.Label lbl_TeamCountry;
        private System.Windows.Forms.Label lbl_TeamCity;
        private System.Windows.Forms.TextBox tBox_TeamName;
        private System.Windows.Forms.TextBox tBox_TeamCountry;
        private System.Windows.Forms.TextBox tBox_TeamCity;
        private System.Windows.Forms.Label lbl_AddingPlayers;
        private System.Windows.Forms.Label lbl_PlayerName;
        private System.Windows.Forms.Label lbl_PlayerNumber;
        private System.Windows.Forms.Label lbl_PlayerPosition;
        private System.Windows.Forms.TextBox tBox_PlayerName;
        private System.Windows.Forms.TextBox tBox_PlayerNumber;
        private System.Windows.Forms.ComboBox comboBox_PlayerPosition;
        private System.Windows.Forms.Button btn_AddTeam;
        private System.Windows.Forms.Button btn_AddPlayers;
        private System.Windows.Forms.ListBox listBox_Players;
        private System.Windows.Forms.Button btn_Remove;
    }
}

