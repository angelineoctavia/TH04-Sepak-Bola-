﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static TH_Sepak_Bola__Week_4_.Form1;

namespace TH_Sepak_Bola__Week_4_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DataTable Tim = new DataTable();
        List<string> country = new List<string>();
        private void Form1_Load(object sender, EventArgs e)
        {
            country.Add("England");
            country.Add("Germany");

            Tim.Columns.Add("Manchester United");
            Tim.Columns.Add("Chelsea");
            Tim.Columns.Add("Bayern Munich");

            Tim.Rows.Add(0, 0, 1);
            comboBox_ChooseCountry.Items.Add("England");
            comboBox_ChooseCountry.Items.Add("Germany");

            Tim.Rows.Add("(01) David De Gea, GK", "(01) Kepa Arrizabalaga, GK", "(01) Manuel Neuer, GK");
            Tim.Rows.Add("(02) Victor Lindelof, DF", "(04) Benoît Badiashile, DF", "(02) Dayot Upamecano, DF");
            Tim.Rows.Add("(04) Phil Jones, DF", "(05) Enzo  Fernández, MF", "(04) Matthijs de Ligt, DF");
            Tim.Rows.Add("(05) Harry Maguire, DF", "(06) Thiago Silva, DF", "(05) Benjamin Pavard, DF");
            Tim.Rows.Add("(06) Lisandro Martinez, DF", "(07) N'Golo Kanté, MF", "(06) Joshua Kimmich, MF");
            Tim.Rows.Add("(08) Bruno Fernandez, MF", "(08) Mateo Kovačić, MF", "(07) Serge Gnabry, FW");
            Tim.Rows.Add("(09) Anthony Martial, FW", "(09) Pierre-Emerick Aubameyang, FW", "(08) Leon Goretzka, MF");
            Tim.Rows.Add("(10) Marcus Rashford, FW", "(10) Christian Pulisic, MF", "(10) Leroy Sané, FW");
            Tim.Rows.Add("(12) Tyrell Malacia, DF", "(11) João Félix, FW", "(14) Paul Wanner, MF");
            Tim.Rows.Add("(14) Christian Eriksen, MF", "(12) Ruben Loftus-Cheek, MF", "(21) Lucas Hernandez, DF");
            Tim.Rows.Add("(18) Casemiro, MF", "(17) Raheem Sterling, MF", "(25) Thomas Müller, FW");
        }
        private void comboBox_ChooseCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox_ChooseTeam.Items.Clear();
            int a = comboBox_ChooseCountry.SelectedIndex;

            for (int i = 0; i < Tim.Columns.Count; i++)
            {
                if (a.ToString() == Tim.Rows[0][i].ToString())
                {
                    comboBox_ChooseTeam.Items.Add(Tim.Columns[i].ColumnName);
                }
            }
        }

        private void comboBox_ChooseTeam_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            listBox_Players.Items.Clear();
            for (int i = 0; i < Tim.Columns.Count; i++)
            {
                if (comboBox_ChooseTeam.SelectedItem == Tim.Columns[i].ColumnName)
                {
                    for (int j = 1; j < Tim.Rows.Count; j++)
                    {
                        if (Tim.Rows[j][i].ToString() != "")
                        {
                            listBox_Players.Items.Add(Tim.Rows[j][i]);
                        }
                       
                    }
                    break;
                }
            }
        }

        private void btn_AddTeam_Click(object sender, EventArgs e)
        {
            int a = 0;
            int b = 0;
            int c = 0;
            if (tBox_TeamName.Text == "" || tBox_TeamCountry.Text == "" || tBox_TeamCity.Text == "")
            {
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string teamName = tBox_TeamName.Text;
                string teamCountry = tBox_TeamCountry.Text;
                string teamCity = tBox_TeamCity.Text;

                for (int i = 0; i < Tim.Columns.Count; i++)
                {
                    if (teamName == Tim.Columns[i].ColumnName)
                    {
                        a++;
                    }
                }
                if (a != 0)
                {
                    MessageBox.Show("Team with same name exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    for (int i = 0;i < country.Count; i++)
                    {
                        if (teamCountry == country[i])
                        {
                            b = i;
                            Tim.Columns.Add(teamName);
                            Tim.Rows[0][Tim.Columns.Count - 1] = b;
                            comboBox_ChooseCountry.Text = "";
                            tBox_TeamName.Text = "";
                            tBox_TeamCountry.Text = "";
                            tBox_TeamCity.Text = "";
                            break;
                        }
                        else
                        {
                            c++;
                            if (c == country.Count)
                            {
                                comboBox_ChooseCountry.Items.Add(teamCountry);
                                country.Add(teamCountry);
                                Tim.Columns.Add(teamName);
                                Tim.Rows[0][Tim.Columns.Count - 1] = country.Count - 1;
                                comboBox_ChooseCountry.Text = "";
                                tBox_TeamName.Text = "";
                                tBox_TeamCountry.Text = "";
                                tBox_TeamCity.Text = "";
                                break;
                            }
                        }
                    }
                }
            }
        }

        private void btn_AddPlayers_Click(object sender, EventArgs e)
        {
            if (comboBox_ChooseCountry.Text == "" || comboBox_ChooseTeam.Text == "" || tBox_PlayerName.Text == "" || tBox_PlayerNumber.Text == "" || comboBox_PlayerPosition.Text == null)
            {
                MessageBox.Show("All Fields Need to be Filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string player = "(" + tBox_PlayerNumber.Text + ") " + tBox_PlayerName.Text + ", " + comboBox_PlayerPosition.SelectedItem;
                for (int i = 0; i < Tim.Columns.Count; i++)
                {
                    if (Tim.Columns[i].ColumnName == comboBox_ChooseTeam.Text)
                    {
                        Tim.Rows.Add();
                        Tim.Rows[Tim.Rows.Count - 1][i] = player;
                        listBox_Players.Items.Add(player);
                    }
                }
            }
            tBox_PlayerName.Text = "";
            tBox_PlayerNumber.Text = "";
            comboBox_PlayerPosition.Text = "";
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (listBox_Players.SelectedItems != null)
            {
                if (listBox_Players.Items.Count > 11)
                {
                    for (int i = 0; i < Tim.Columns.Count; i++)
                    {
                        if (Tim.Columns[i].ColumnName == comboBox_ChooseTeam.SelectedItem)
                        {
                            for (int j = 1; j < Tim.Rows.Count; j++)
                            {
                                if (Tim.Rows[j][i].ToString() == listBox_Players.SelectedItem)
                                {
                                    Tim.Rows[j][i] = "";
                                    listBox_Players.Items.Remove(listBox_Players.SelectedItem);
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Unable to Remove Players if Players less than equal 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}